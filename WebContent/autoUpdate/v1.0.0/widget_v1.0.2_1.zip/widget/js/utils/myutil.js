/*
 * LAIXIAO Server JavaScript Library
 */
(function(window,undefined){
    var MyUtil = {};
    MyUtil.loading_gif2_1 = "widget://res/image/loading.gif";
    
    /**
     * 校验是否是手机号码
     */
	MyUtil.validPhone = function(p_number,callback) {
		var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
		if(myreg.test($.trim(p_number))){ 
		    callback(true); 
		}else{
			callback(false); 
		}
	}
	MyUtil.validNumber = function(objValue){  
	    var reg = new RegExp("^[0-9]*$");  
	    if(reg.test(objValue)){  
	        return true;
	    }else{
	    	return false;
	    }
	} 
	/*
	 * 说明：缩略图插件，它能够“截图”图片的某一部分作为缩略图或者完全等比例缩放.
	 * 参考文档： 	
	 * 		http://www.dowebok.com/46.html
	 * 		https://github.com/VuongN/jQuery-Fakecrop
	 * 使用：
	 * 		1.导入jquery.fakecrop.js
	 * 		2.<div ><img class="img_corp" src="img/s1.jpg"></div>
	 * 		
	 * 参数：
	 * 		widthScope ： 宽度比（0.5即是屏幕的一半大小）
	 */
    MyUtil.fakecropImg = function(className,widthScope){
    	var winWidth = api.winWidth;
    	$(className).fakecrop({
			fill: true,
			center: true,
	    	wrapperWidth: winWidth*widthScope,
	    	wrapperHeight: winWidth*widthScope,
	    });
	    //处理完后删除指定class
	   	var imgs = $api.domAll(className);
    	for(var i=0; i<imgs.length; i++){
    		$api.removeCls(imgs[i], className.slice(1,className.length));
    	}
    }
    /*
     * 参数：
	 * 		w ： 宽比（0.5即是屏幕的一半大小）
	 * 		h ： 高比（0.5即是屏幕的一半大小）
     */
    MyUtil.fakecropImg2 = function(className,w,h){
    	var winWidth = api.winWidth;
    	$(className).fakecrop({
			fill: true,
			center: true,
	    	wrapperWidth: winWidth*w,
	    	wrapperHeight: winWidth*h,
	    });
	    //处理完后删除指定class
	   	var imgs = $api.domAll(className);
    	for(var i=0; i<imgs.length; i++){
    		$api.removeCls(imgs[i], className.slice(1,className.length));
    	}
    }
    /**
     * 图片压缩处理：https://github.com/think2011/localResizeIMG/wiki/2.-%E5%8F%82%E6%95%B0%E6%96%87%E6%A1%A3
     * 
     * 使用流程：
     * 		1.导入lrz.bundle.js
     * 
	 * @param {Object} imagePath	图片路径
	 * @param {Object} compressQuality	压缩压缩质量0.5
	 * @param {Object} callback		压缩成功：返回压缩后的文件全路径；压缩失败：返回原图路径。
     */
    MyUtil.compressImage = function(imagePath,compressQuality,callback){
    	var self = this;	
    	var fs = api.require('fs');
        var trans = api.require('trans');
        
		fs.getAttribute({
		    path: imagePath
		}, function(ret1, err) {
		    if (ret1.status) {
		    	var fileSize = ret1.attribute.size/1024;
		    	var quality = 1;
		    	//console.log("压缩前:"+fileSize+"k")
		    	if(fileSize > 3072){
		    		quality = 0.6;
		    		startCompress(imagePath,quality,callback);
		    	}else if(fileSize > 2048){
		    		quality = 0.65;
		    		startCompress(imagePath,quality,callback);
		    	}else if(fileSize > 1024){
		    		quality = 0.7;
		    		startCompress(imagePath,quality,callback);
		    	}else if(fileSize > 512){
		    		quality = 0.75;
		    		startCompress(imagePath,quality,callback);
		    	}else if(fileSize > 256){
		    		quality = 0.8;
		    		startCompress(imagePath,quality,callback);
		    	}else{
		    		 callback(imagePath);
		    	}
		    }else {
		        console.log("文件读取错误："+JSON.stringify(err));
		        startCompress(imagePath,quality,callback);
		    }
		    
		});
        
		var startCompress = function(imagePath,compressQuality,callback){
			var compressDir = api.cacheDir +"/xiaoba/compress/";//压缩保存路径
			var fileName = imagePath.substring(imagePath.lastIndexOf("/") + 1);
	      	fs.exist({
	            path: compressDir+fileName
	        },function(ret,err){
	            if(ret.exist){
	                callback(compressDir+fileName);
	            }else {
	    			lrz(imagePath,
	    			{ 
						//width:elOffset.w*3,
						//height:elOffset.h, 
						quality: compressQuality,
						fieldName: fileName
					}).then(function (rst) {
			            // 处理成功会执行
			            //console.log(rst.base64)
			            var base64Str = rst.base64.replace('data:image/jpeg;base64,','');
			            trans.saveImage({
						    base64Str: base64Str,
						    album: false,
						    imgPath: compressDir,
						    imgName: fileName
						}, function(ret, err) {
						    if (ret.status) {
						       	callback(compressDir+fileName);
						    } else {
						    	callback(imagePath);
						        console.log("图片压缩处理失败："+err.msg);
						    }
						});
				    }).catch(function (err){
			            // 处理失败会执行
			            callback(imagePath);
				    }).always(function () {
			            // 不管是成功失败，都会执行
			            
				    });
	            }
	        });
		}
    }
    MyUtil.compressImage2 = function(imagePath,compressQuality,callback){
    	var self = this;	
    	var fs = api.require('fs');
        var trans = api.require('trans');
        
		var compressDir = api.cacheDir +"/xiaoba/compress/";//压缩保存路径
		var fileName = imagePath.substring(imagePath.lastIndexOf("/") + 1);
//		fs.getAttribute({
//		    path: imagePath
//		}, function(ret1, err) {
//		    if (ret1.status) {
//		    	var fileSize = ret1.attribute.size/1024;
//		    	console.log("压缩前："+fileSize + "k");
//		    }
//		});
      	fs.exist({
            path: compressDir+fileName
        },function(ret,err){
            if(ret.exist){
                callback(compressDir+fileName);
            }else {
    			lrz(imagePath,{ 
					//width:elOffset.w*3,
					//height:elOffset.h, 
					quality: compressQuality,
					fieldName: fileName
				}).then(function (rst) {
		            // 处理成功会执行
		            //console.log(rst.base64)
		            var base64Str = rst.base64.replace('data:image/jpeg;base64,','');
		            trans.saveImage({
					    base64Str: base64Str,
					    album: false,
					    imgPath: compressDir,
					    imgName: fileName
					}, function(ret, err) {
					    if (ret.status) {
//					    	fs.getAttribute({
//							    path: compressDir+fileName
//							}, function(ret2, err) {
//							    if (ret2.status) {
//							    	var fileSize2 = ret2.attribute.size/1024;
//							    	console.log("压缩后："+fileSize2 + "k");
//							    }
//							});
					       	callback(compressDir+fileName);
					    } else {
					    	callback(imagePath);
					        console.log("图片压缩处理失败："+err.msg);
					    }
					});
			    }).catch(function (err){
		            // 处理失败会执行
		            callback(imagePath);
			    }).always(function () {
		            // 不管是成功失败，都会执行
		            
			    });
            }
        });
    }
    /*
     * 
     * 图片缓存: 使用echo.js异步加载图片并缓存图片到本地
     * 参考文档：http://community.apicloud.com/bbs/forum.php?mod=viewthread&tid=25504&extra=		
     * 引用：	echo.min.js
     * 使用示例：<img data-id="laixiao" data-cache-url="http://img.mmjpg.com/2017/911/1.jpg" src="../../res/image/loading.gif" data-echo="../../res/image/loading.gif" class="aui-img-object aui-pull-left" data-class="aui-img-object"/>
     * 说明：
     * 		src				//默认图片
     * 		data-echo		//加载中图片
     * 		data-cache-url	//图片url
     * 		data-id			//图片的唯一ID
     */
	MyUtil.cacheImg = function() {
		var winHeight = api.winHeight;
		echo.init({
            offset : winHeight/4,	//离可视区域多少像素的图片可以被加载
            throttle : 0, 			//设置图片延迟加载的时间
            unload : false,
            callback : function(element, op) {
                var url = element.getAttribute('data-cache-url');
                var quequeid = element.getAttribute('data-id');
                var c = element.getAttribute('data-class');
                if (op === 'load') {
                    sdk_cache.queque.add(quequeid, url, function(ret) {
                        var el = $("img."+c+"[data-id='" + ret.id + "']");

                        var path = ret.url;

						el.attr('src', path);
                        el.removeAttr('data-cache-url');
                        el.removeAttr('data-echo');
                    });

                }
            }
        });
	}
	//2倍手机屏幕高度可见
	MyUtil.cacheImg2 = function() {
		var winHeight = api.winHeight;
		echo.init({
            offset : 2*winHeight,	//离可视区域多少像素的图片可以被加载
            throttle : 0, 			//设置图片延迟加载的时间
            unload : true,
            callback : function(element, op) {
                var url = element.getAttribute('data-cache-url');
                var quequeid = element.getAttribute('data-id');
                var c = element.getAttribute('data-class');
                if (op === 'load') {
                    sdk_cache.queque.add(quequeid, url, function(ret) {
                        var el = $("img."+c+"[data-id='" + ret.id + "']");

                        var path = ret.url;
                      
                        el.attr('src', path);
                        el.removeAttr('data-cache-url');
                        el.removeAttr('data-echo');
                    });

                }
            }
        });
	}
	//不使用懒加载
	var i = 0;
	MyUtil.cacheImg3 = function(imageArray,callback) {
//		var imageJsonData = [
//			{ quequeid: "laixiao", url: "https://laixiao.png" },
//			{ quequeid: "laixiao", url: "https://laixiao.png" },
//		];
		if(i < imageArray.length){
			sdk_cache.queque.add(imageArray[i].quequeid, imageArray[i].url, function(ret) {
				var path = ret.url;
				//console.log(path);
				i++;
				if(i == imageArray.length){
					i = 0;
	           	 	callback(true);
				}else{
					MyUtil.cacheImg3(imageArray,callback);
				}
	        });
		}
	}
    /*
     * 检查是否已经登陆
     */
    MyUtil.checkLogin = function(callback){
    	if(typeof(api) != "undefined"){
    		api.getPrefs({
			    key: 'accessToken'
			}, function(ret, err) {
			    var accessToken = ret.value;
			    if(accessToken != ""){
			    	callback(true);
			    }else{
			    	callback(false);
			    }
			});
    	}
    }
    /*
     * 检测是否登陆：仅限主页可用
     */
	MyUtil.checkLogin_main = function(callback){
		var self = this;
		self.checkLogin(function(isLogin){
			if(!isLogin){
				api.confirm({
				    title: '提示',
				    msg: '请先登陆',
				    buttons: ['登录', '取消']
				}, function(ret, err) {
				    var index = ret.buttonIndex;
				    if(index == 1){
				    	api.openWin({
				    		name: 'user_login_win',
					        url: '../user/user_login_win.html',
					        reload: true
				    	});
				    }
				});
				callback(false);
			}else{
				callback(true);
			}
		});
	}
    /*
     * 注销登陆
     */
    MyUtil.loginOut = function(callback){
    	api.setPrefs({key: 'accessToken',value: ""});
		api.setPrefs({key: 'refreshToken',value: ""});
		api.setPrefs({key: 'user',value: ""});
		//断开融云连接
		api.setPrefs({key: 'rongToken',value: ""});
		var rong = api.require('rongCloud2');
		rong.logout(function(ret, err) { }); // 断开，且不再接收 Push
		//刷新侧滑视图
		api.execScript({ name: 'slide', script: 'refreshView();' });
		//刷新数字
		api.setPrefs({ key: 'orderCount', value: ''});
		api.setPrefs({ key: 'questionCount', value: ''});
		api.setPrefs({ key: 'reserveCount', value: ''});
		api.setPrefs({ key: 'commentCount', value: ''});
		api.setPrefs({ key: 'reportCount', value: ''});
		api.execScript({ name: 'slide', script: 'initCount();' });
		//主页归零
		api.setPrefs({key: 'frame_index',value: 0});
		api.toast({msg: "注销成功，请重新登陆"})
		setTimeout(function(){
			api.closeWin({});
		},500);
    }

	/*
	 * 根据月份和日期判断星座
	 */
	MyUtil.Constellation = function(month,date) { 
		var value = "";
		if (month == 1 && date >=20 || month == 2 && date <=18) {value = "水瓶座";} 
		if (month == 2 && date >=19 || month == 3 && date <=20) {value = "双鱼座";} 
		if (month == 3 && date >=21 || month == 4 && date <=19) {value = "白羊座";}
		if (month == 4 && date >=20 || month == 5 && date <=20) {value = "金牛座";} 
		if (month == 5 && date >=21 || month == 6 && date <=21) {value = "双子座";} 
		if (month == 6 && date >=22 || month == 7 && date <=22) {value = "巨蟹座";} 
		if (month == 7 && date >=23 || month == 8 && date <=22) {value = "狮子座";} 
		if (month == 8 && date >=23 || month == 9 && date <=22) {value = "处女座";} 
		if (month == 9 && date >=23 || month == 10 && date <=22) {value = "天秤座";} 
		if (month == 10 && date >=23 || month == 11 && date <=21) {value = "天蝎座";} 
		if (month == 11 && date >=22 || month == 12 && date <=21) {value = "射手座";} 
		if (month == 12 && date >=22 || month == 1 && date <=19) {value = "摩羯座";} 
		return value;
	} 
	/**
	 * 判断字符串是否是金钱
	 */
	MyUtil.CheckMoney = function(money){
		var reg = /(^[1-9]([0-9]+)?(\.[0-9]{1,2})?$)|(^(0){1}$)|(^[0-9]\.[0-9]([0-9])?$)/;
	    if (reg.test(money)) {
	         return true;
	    }else{
	         return false;
	    };
		//000 错
	    //0 对
	    //0. 错
	    //0.0 对
	    //050 错
	    //00050.12错
	    //70.1 对
	    //70.11 对
	    //70.111错
	    //500 正确
	}
	/**
	 * 获取星期
	 */
	MyUtil.getTime1 = function(time1){
		var objD = time1;
		if(objD == null){
			objD = new Date();
		}
		var str, colorhead, colorfoot;
	    var yy = objD.getYear();
	    if (yy < 1900) yy = yy + 1900;
	    var MM = objD.getMonth() + 1;
	    if (MM < 10) MM = '0' + MM;
	    var dd = objD.getDate();
	    if (dd < 10) dd = '0' + dd;
	    var hh = objD.getHours();
	    if (hh < 10) hh = '0' + hh;
	    var mm = objD.getMinutes();
	    if (mm < 10) mm = '0' + mm;
	    var ss = objD.getSeconds();
	    if (ss < 10) ss = '0' + ss;
	    var ww = objD.getDay();
	    if (ww == 0) colorhead = "";
	    if (ww > 0 && ww < 6) colorhead = "";
	    if (ww == 6) colorhead = "";
	    if (ww == 0) ww = "星期日";
	    if (ww == 1) ww = "星期一";
	    if (ww == 2) ww = "星期二";
	    if (ww == 3) ww = "星期三";
	    if (ww == 4) ww = "星期四";
	    if (ww == 5) ww = "星期五";
	    if (ww == 6) ww = "星期六";
	    colorfoot = ""
	    str = colorhead + yy + "-" + MM + "-" + dd + " " + hh + ":" + mm + ":" + ss + " " + ww + colorfoot;
	    
	    return (str);
	}
	/**
	 * 根据IP获取当前城市地址信息
	 */
	MyUtil.GetCityInfo = function(callback) {
	    var cityUrl = 'http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=js';
	    $.getScript(cityUrl, function (script, textStatus, jqXHR) {
	    	// 获取城市
	        //var citytq = remote_ip_info.city; 
			callback(remote_ip_info);
	    });
    }
	/**
	 * 根据城市获取天气
	 	参考文档:http://www.jb51.net/article/85959.htm
	 */
	MyUtil.GetWeather = function(citytq,callback) {
        var url = "http://php.weather.sina.com.cn/iframe/index/w_cl.php?code=js&city=" + citytq + "&day=0&dfc=3";
        $.ajax({
	        url: url,
	        dataType: "script",
	        scriptCharset: "gbk",
	        success: function (data) {
	        	//1.获取天气json
	        	//var weather = window.SWther.w[citytq][0];
	        	var weather = window.SWther;
	        	//2.获取天气图片
	            var _f = weather.f1 + "_0.png";
	            if (new Date().getHours() > 17) {
	              _f = weather.f2 + "_1.png";
	            }
	            var imgUrl = "http://i2.sinaimg.cn/dy/main/weather/weatherplugin/wthIco/20_20/" + _f;
	            //3.返回数据
	            //var tq = "今日天气 :　" + citytq + " " + imgUrl + " " + weather.s1 + " " + weather.t1 + "℃～" + weather.t2 + "℃ " + weather.d1 + weather.p1 + "级";
//	            console.log(imgUrl);
//	            console.log(JSON.stringify(weather))
//				console.log(JSON.stringify(window.SWther))

	            callback(weather);
	        }
        });
	}
	/**
	 * 举报
	 */
	MyUtil.Report = function(types,touserid,artId){
		var reportData = [];
    	MyUtil.checkLogin(function(isLogin){
			if(isLogin){
				Server.Reportcategory_FindByMapPage({jsonStr: JSON.stringify({state: 0}), first: 0, max: 100},function(data){
					for(var i=0; i<data.length; i++){
						reportData.push(data[i].name);
					}
				  	api.actionSheet({
					    title: '请选择举报原因',
					    cancelTitle: '取消',
					    buttons: reportData
					}, function(ret, err) {
					    var index = ret.buttonIndex;
					    if(index != reportData.length+1){
					    	//api.toast({msg: "举报成功"+ data[index-1].name});
					    	var req_data = {
					        	reportcategoryid: data[index-1].id,	//举报分类id
					        	types: types,							//举报类型: 0：撸友1：糗事2：二手3：自拍秀4：说说
					        	touserid: touserid,	//被举报人
					        	state: 0,
					        	
					        	shuoshuoid: artId,
					        	selfieid: artId,
					        	secondproductid: artId,
					        	jokeid: artId,
					        	gameid: artId,
					        };
					    	Server.Reportinformation_Insert(req_data,function(data2){
					    		//console.log(JSON.stringify(data))
					    		api.toast({msg: data2.msg});
					    	});
					    }
					});
				});
			}else{
				api.toast({msg: "请先登录"});
			}
		});
	}
	//分享接口
	MyUtil.Share = function(title,description){
		api.actionSheet({
		    title: '分享App到',
		    cancelTitle: '取消',
		    buttons: ['腾讯QQ']
		}, function(ret, err) {
		    var index = ret.buttonIndex;
		    if(index == 1){
		    	var qq = api.require('QQPlus');
				qq.installed(function(ret, err) {
				    if(ret.status){
				       	qq.shareNews({
						    url: 'https://eryecao.github.io/xiaoba/WebContent/xiaoba_office.html',
						    title: title,
						    description: description,
						    imgUrl: 'https://eryecao.github.io/xiaoba/WebContent/images/logo512.png',
						    type: 'QFriend'
						},function(ret,err){
						  if (ret.status){
						    api.toast({msg: "分享成功"});
						  }else{
						  	if(err.code == -1){
						  		api.toast({msg: "您取消了分享操作"});
						  	}
						    //console.log(JSON.stringify(err))
						  }
						});
				    }else{
				        api.toast({msg: "QQ未安装"});
				    }
				});
		    }
		});
	}


	MyUtil.sdk_cache = sdk_cache;

    window.MyUtil = MyUtil;
})(window);




var sdk_cache = {
    queque : {
        stacks : [],
        downloading : false,
        add : function(id, url, callback) {
            this.stacks.push({
                    'id' : id,
                    'url' : url,
                    'callback' : callback
            });
            setTimeout(sdk_cache.queque.begin,1);
        },
        begin : function() {
            var item = sdk_cache.queque.stacks.pop();
            //出栈
            if (item) {
                sdk_cache.queque.downloading = true;
                var i_url = item.url;
                if(i_url.indexOf('https://') != -1) {
                    sdk_cache.imageCache.get(item.url, function(ret, err) {
                        sdk_cache.queque.downloading = false;
                        var path = item.url;
                        if (ret) {
                                path = ret.url;
                        }
                        item.callback({
                                'id' : item.id,
                                'url' : path,
                                'err' : err
                        });
//                          updatePersonHeadImgToDb(item.id, path, function(is_true){
//                                  if(is_true){
//                                          //continue download
//                                          setTimeout(function() {
//                                                  sdk_cache.queque.begin();
//                                          }, 1);
//                                  }
//                          });
                    });
                } else {
                    item.callback({
                        'id' : item.id,
                        'url' : i_url,
                        'err' : ''
                    });
                }
                
            }
        }
    },
    imageCache : {
        get : function(url, callback) {
            if (api.systemType != 'ios') {//android 可用
                api.imageCache({
                        'url' : url,
                        policy : 'cache_only',
                        thumbnail : false
                }, callback);
                return;
            }
            var r = /https:\/\/.*?\/(.*?\.(?:png|jpg|gif|jpeg))([?!]?.*)/i;
            var m = r.exec(url);
            var ver = "";
            var filename = "";
            if (m != null) {
                filename = m[1].replace(/[\/]/gi, '');
                ver = m[2];
            }
            if (filename == '') {
                callback(null, 'err:not remote url');
                return;
            }

            var path = api.cacheDir + "/imagecache/" + filename;
            var fs = api.require('fs');
            fs.exist({
                path : path
            }, function(ret, err) {
                if (ret.exist) {//缓存文件已存在
                    if (ret.directory) {
                        //api.alert({msg:'imageCache.path -> 路径指向一个文件夹'});
                        callback(null, 'imageCache.path -> 路径指向一个文件夹');
                    } else {
                        fs = null;
                        callback({
                                'url' : path
                        }, 'cache exists');

                        return;
                    }
                } else {
                    api.download({
                        'url' : url,
                        savePath : path,
                        report : true,
                        cache : true,
                        allowResume : true
                    }, function(ret, err) {
                        fs = null;
                        if (ret) {
                                if (ret.state == 1) {//0下载中，1，下载完成，2，下载失败
                                        callback({
                                                'url' : ret.savePath
                                        }, '');
                                } else if (ret.state == 2) {
                                        callback(null, '下载失败:' + url);
                                }
                                //var value = ('文件大小：' + ret.fileSize + '；下载进度：' + ret.percent + '；下载状态' + ret.state + '存储路径: ' + ret.savePath);
                                return;
                        }//download error
                        callback(null, err.msg);

                    });
                }
            });
        },
        clear : function() {
            api.clearCache();
        }
    }
};
