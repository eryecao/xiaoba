/*
 * APICloud JavaScript Library
 * Copyright (c) 2014 apicloud.com
 */
(function(window,$,JSEncrypt){
    var Server = {};
   	/**
     * 服务器的IP地址 :	
     * 	https://119.23.78.65:443/EryecaoServer 
     */
    Server.ipAddress = "https://119.23.78.65:443/EryecaoServer";
    Server.fileUpload = "/File/Upload2";
    Server.fileOnlineOpenUrl = "https://119.23.78.65:443/EryecaoServer/File/OnlineOpen/";
    Server.fileUrl = "https://119.23.78.65:443/EryecaoServer/File/OnlineOpenThumbnailator/";
    
    Server.OnlineOpen1024 = "https://119.23.78.65:443/EryecaoServer/File/OnlineOpen1024/";
    Server.OnlineOpen512 = "https://119.23.78.65:443/EryecaoServer/File/OnlineOpen512/";
    Server.OnlineOpenThumbnailator512 = "https://119.23.78.65:443/EryecaoServer/File/OnlineOpenThumbnailator512/";
    Server.OnlineOpenThumbnailator256 = "https://119.23.78.65:443/EryecaoServer/File/OnlineOpenThumbnailator256/";
    
    /**
     *	获取公钥字符串
     */
    Server.getRSAPublic = function(callback){
    	var self = this;
    	var url = self.ipAddress + "/Rsa/GetPublic";
    	api.ajax({
		    url: url,
		    method: 'get',
		    dataType: 'json',
		}, function(ret, err) {
		    if (ret) {
	        	callback(ret.publickey);
		    } else {
		        api.toast({ msg: "请检查您的网络"});
		    }
		});
    }
    /**
     *	获取加密对象 
     */
    Server.getEncrypt = function(callback){
    	this.getRSAPublic(function(publickey){
			var encrypt = new JSEncrypt();
	    	encrypt.setPublicKey(publickey);
	    	callback(encrypt);          
		});	
    }
    /*
     * 刷新访问令牌
     */
    Server.refreshToken = function(callback){
    	var self = this;
    	api.getPrefs({
		    key: 'refreshToken'
		}, function(ret, err) {
	    	var refreshToken = ret.value;
			var url = self.ipAddress + "/Jwt/RefreshToken";
			api.ajax({
			    url: url,
			    method: 'post',
			    headers: {  
		            "Authentication": refreshToken,  
		        },
		        dataType: 'json',
			}, function(ret, err) {
			    if (ret) {
	            	if(ret.code == 4444){
	            		//api.toast({msg: "刷新访问令牌的令牌已经过期，请重新登陆。"});
	            		//刷新访问令牌的令牌已经过期，请重新登陆。
	            		api.setPrefs({key: 'accessToken',value: ""});
        				api.setPrefs({key: 'refreshToken',value: ""});
        				api.setPrefs({key: 'user',value: ""});
        				callback(false);
	            	}else{
	            		//api.toast({msg: "刷新访问令牌成功"});
	            		api.setPrefs({key: 'accessToken',value: ret.accessToken});
        				api.setPrefs({key: 'refreshToken',value: ret.refreshToken});
	            		callback(true);
	            	}
			    } else {
			        api.toast({ msg: "请检查您的网络"});
			    }
			});
	   	});
    }
    
  	/*
     * Get方法获取数据
     */
    Server.Get = function(url,req_data,callback){
    	var self = this;
    	api.getPrefs({
		    key: 'accessToken'
		}, function(ret, err) {
		    var accessToken = ret.value;
			api.ajax({
			    url: url,
			    method: 'get',
			    headers: {  
		            "Authentication": accessToken,  
		        },
		        data: req_data,
		        dataType: 'json',
			}, function(ret, err) {
			    if (ret) {
	            	if(ret.code == 4444){
	            		//刷新访问令牌
	            		self.refreshToken(function(isRefresh){
	            			if(isRefresh){
	            				//api.toast({msg: "再次请求数据"});
	            				self.Get(url,req_data,callback);
	            			}else{
	            				//api.toast({msg: "身份信息已过期，请重新登陆！"});	
	            			}
	            		});
	            	}else{
	            		callback(ret);
	            	}
			    } else {
			    	console.log(JSON.stringify(err))
			        api.toast({ msg: "请检查您的网络"});
			    }
			});
		});
    }
  	/*
     * Get2方法获取数据：无需令牌
     */
    Server.Get2 = function(url,req_data,callback){
    	var self = this;
    	api.ajax({
		    url: url,
		    method: 'get',
	        data: req_data,
	        dataType: 'json',
		}, function(ret, err) {
		    if (ret) {
            	callback(ret);
		    } else {
		    	console.log(JSON.stringify(err))
		        api.toast({ msg: "请检查您的网络"});
		    }
		});
    }
  	/*
     * Post方法获取数据
     */
    Server.Post = function(url,req_data,callback){
    	var self = this;
    	api.getPrefs({
		    key: 'accessToken'
		}, function(ret, err) {
		    var accessToken = ret.value;
		    api.ajax({  
		    	url: url,  
		        method: "post",  
		        data: req_data,
		        dataType: "json",  
		        cache: true,
		        headers: {  
		            "Authentication": accessToken,  
		        },
		    }, function(ret, err) {
            	if(ret.code == 4444){
            		//刷新访问令牌
            		self.refreshToken(function(isRefresh){
            			if(isRefresh){
            				self.Post(url,req_data,callback);
            			}else{
            				api.toast({msg: "身份信息已过期，请重新登陆！"});
            			}
            		});
            	}else{
            		callback(ret);
            	}
			}); 
		});
    }
    /*
     * Post2方法获取数据：无需令牌
     */
    Server.Post2 = function(url,req_data,callback){
    	var self = this;
    	api.getPrefs({
		    key: 'accessToken'
		}, function(ret, err) {
		    var accessToken = ret.value;
		    api.ajax({  
		    	url: url,  
		        method: "post",  
		        data: req_data,
		        dataType: "json",  
		        cache: true,
		        headers: {  
		            "Authentication": accessToken,  
		        },
		    }, function(ret, err) {
            	if(ret.code == 4444){
            		//刷新访问令牌
            		self.refreshToken(function(isRefresh){
            			if(isRefresh){
            				self.Post(url,req_data,callback);
            			}else{
            				api.toast({msg: "身份信息已过期，请重新登陆！"});
            			}
            		});
            	}else{
            		callback(ret);
            	}
			}); 
		});
    }
    
//============================================用户=========================================================
    /**
     * 用户登陆
 	 * @param {Object} username
 	 * @param {Object} password
     */
    Server.login = function(username,password,callback){
    	var self = this;
    	this.getEncrypt(function(encrypt){
			var reqData = encrypt.encrypt(JSON.stringify({username:username, password:password}));
			var url = self.ipAddress + "/User/Login";
         	api.ajax({
			    url: url,
			    method: 'post',
			    dataType: 'json',
			    data: {
			        values: {
			            data: reqData
			        }
			    },
			}, function(ret, err) {
			    if (ret) {
			    	if(ret.code == 1){
			    		api.setPrefs({key: 'accessToken',value: ret.accessToken});
        				api.setPrefs({key: 'refreshToken',value: ret.refreshToken});
	        			//更新个人信息
	        			self.User_FindByAccessToken(function(ret2){
							api.setPrefs({key: 'user',value: JSON.stringify(ret2)});
	        				//刷新侧滑页面
					      	api.execScript({ name: 'slide', script: 'refreshView();' });
							callback(ret);
				      	});
	        		}else{
	        			callback(ret);
	        		}
			    } else {
			        api.toast({ msg: JSON.stringify(err) });
			    }
			});
		});
    }
	/**
     * 用户注册
 	 * @param {Object} username
 	 * @param {Object} password
     */
    Server.Register = function(username,password,callback){
    	var self = this;
    	this.getEncrypt(function(encrypt){
			var reqData = encrypt.encrypt(JSON.stringify({username:username, password:password}));
	     	var url = self.ipAddress + "/User/Register";
         	api.ajax({
			    url: url,
			    method: 'post',
			    dataType: 'json',
			    data: {
			        values: {
			            data: reqData
			        }
			    },
			}, function(ret, err) {
			    if (ret) {
			    	if(ret.code == 1){
			    		api.setPrefs({key: 'accessToken',value: ret.accessToken});
        				api.setPrefs({key: 'refreshToken',value: ret.refreshToken});
	        			//更新个人信息
	        			self.User_FindByAccessToken(function(ret2){
				    		api.setPrefs({key: 'user',value: JSON.stringify(ret2)});
	        				callback(ret);
				      	});
	        		}else{
	        			callback(ret);
	        		}
			    } else {
			        api.toast({ msg: JSON.stringify(err) });
			    }
			});
		});
    }
    
    Server.User_FindPassword = function(req_data,callback){
    	var self = this;
    	var url = self.ipAddress + "/User/FindPassword";
    	self.Get2(url,{values:req_data},function(ret){
    		if(ret.code == 1){
    			api.setPrefs({key: 'accessToken',value: ret.accessToken});
				api.setPrefs({key: 'refreshToken',value: ret.refreshToken});
    			//更新个人信息
    			self.User_FindByAccessToken(function(ret2){
		    		api.setPrefs({key: 'user',value: JSON.stringify(ret2)});
    				callback(ret);
		      	});
    		}else{
    			callback(ret);
    		}
    	});
    }
    
    Server.User_FindByAccessToken = function(callback){
   		var self = this;
   		var url = self.ipAddress + "/User/FindByAccessToken";
   		self.Get(url,{},function(ret){
   			api.setPrefs({key: 'user',value: JSON.stringify(ret)});
   			//刷新侧滑页面
	      	api.execScript({ name: 'slide', script: 'refreshView();' });
   			callback(ret);
   		});
    }
    Server.User_AlterBean = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/User/AlterBean";
   		self.Get(url,{values:req_data},function(ret){
   			if(ret.code == 1){
   				//更新个人信息
	   			self.User_FindByAccessToken(function(ret2){
		    		api.setPrefs({key: 'user',value: JSON.stringify(ret2)});
		    		//刷新侧滑页面
			      	api.execScript({ name: 'slide', script: 'refreshView();' });
					callback(ret);
		      	});
   			}else{
   				callback(ret);
   			}
   		});
    }
    Server.User_UpdateByMap = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/User/UpdateByMap";
   		self.Get(url,{values:req_data},function(ret){
   			if(ret.code == 1){
   				//更新个人信息
	   			self.User_FindByAccessToken(function(ret2){
		    		api.setPrefs({key: 'user',value: JSON.stringify(ret2)});
		    		//刷新侧滑页面
			      	api.execScript({ name: 'slide', script: 'refreshView();' });
					callback(ret);
		      	});
   			}else{
   				callback(ret);
   			}
   		});
    }
    Server.User_FindById = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/User/FindById";
   		self.Get2(url,{values:req_data},function(ret){
   			//更新个人信息
   			callback(ret);
   		});
    }
    
//===============================二手商品分类======================================================
    Server.Firstcategory_FindAll = function(callback){
   		var self = this;
   		var url = self.ipAddress + "/Firstcategory/FindAll";
   		var req_data = {first: 0, max: 100};
   		self.Get2(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Secondcategory_FindAll = function(callback){
   		var self = this;
   		var url = self.ipAddress + "/Secondcategory/FindAll";
   		var req_data = {first: 0, max: 1000};
   		self.Get2(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  
//=================================二手商品==============================================
   	Server.SecondProduct_Insert = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/SecondProduct/Insert";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.SecondProduct_FavourByAuthentication = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/SecondProduct/FavourByAuthentication";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.SecondProduct_ReserveByAuthentication = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/SecondProduct/ReserveByAuthentication";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
 	Server.SecondProduct_FindByIn = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/SecondProduct/FindByIn";
   		self.Get2(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
 	Server.SecondProduct_FindByInMap = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/SecondProduct/FindByInMap";
   		self.Get2(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.SecondProduct_FindById = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/SecondProduct/FindById";
   		self.Get2(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.SecondProduct_FindByKeyword = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/SecondProduct/FindByKeyword";
   		self.Get2(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.SecondProduct_FindByKeywordPage = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/SecondProduct/FindByKeywordPage";
   		self.Get2(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.SecondProduct_FindByMapPage = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/SecondProduct/FindByMapPage";
   		self.Get2(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.SecondProduct_UpdateByMap = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/SecondProduct/UpdateByMap";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	//收藏
 	Server.Collect_Insert = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Collect/Insert";
   		self.Get(url,{values: req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Collect_FindByMapPage = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Collect/FindByMapPage";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Collect_GetCountByMap = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Collect/GetCountByMap";
   		self.Get2(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	
  	//提问
  	Server.Question_Insert = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Question/Insert";
   		self.Get(url,{values: req_data},function(ret){
   			callback(ret);
   		});
    }
 	Server.Question_UpdateByMap = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Question/UpdateByMap";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Question_FindByMapPage = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Question/FindByMapPage";
   		self.Get2(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Question_FindQuestionByState = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Question/FindQuestionByState";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Question_GetCountByMapTables = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Question/GetCountByMapTables";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	
//===============================糗事===============================
  	Server.Jokecategory_FindByMapPage = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Jokecategory/FindByMapPage";
   		self.Get2(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Joke_Insert = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Joke/Insert";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Joke_FindByMapPage = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Joke/FindByMapPage";
   		self.Get2(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Joke_UpdateByMap = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Joke/UpdateByMap";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Joke_FavourByAuthentication = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Joke/FavourByAuthentication";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Jokecomment_FavourByAuthentication = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Jokecomment/FavourByAuthentication";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Jokecollect_Insert = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Jokecollect/Insert";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	//糗事收藏：需要令牌
  	Server.Jokecollect_FindByMapPage = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Jokecollect/FindByMapPage";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Jokecomment_GetCountByMapTables = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Jokecomment/GetCountByMapTables";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Jokecomment_FindByPage = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Jokecomment/FindByPage";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Jokecomment_FindByUnread = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Jokecomment/FindByUnread";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }  	
  	Server.Jokecomment_Insert = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Jokecomment/Insert";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Jokecomment_FindByMapPage = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Jokecomment/FindByMapPage";
   		self.Get2(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }

//=================================说说============================
  	Server.Shuoshuo_Insert = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Shuoshuo/Insert";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Shuoshuo_UpdateByMap = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Shuoshuo/UpdateByMap";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
 	Server.Shuoshuo_FavourByAuthentication = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Shuoshuo/FavourByAuthentication";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Shuoshuocomment1_Insert = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Shuoshuocomment1/Insert";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Shuoshuocomment2_Insert = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Shuoshuocomment2/Insert";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Shuoshuocomment1_GetCountByMapTables = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Shuoshuocomment1/GetCountByMapTables";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Shuoshuocomment1_FindByUnread = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Shuoshuocomment1/FindByUnread";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }  	
  	Server.Shuoshuocomment1_FindByState = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Shuoshuocomment1/FindByState";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }   	
  	  	
  	Server.Shuoshuo_FindByMapPage = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Shuoshuo/FindByMapPage";
   		self.Get2(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
 	Server.Shuoshuocomment1_FindByMapPage = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Shuoshuocomment1/FindByMapPage";
   		self.Get2(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
 	
//===============================自拍秀==================================
	Server.Selfie_Insert = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Selfie/Insert";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
	Server.Selfie_UpdateByMap = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Selfie/UpdateByMap";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
 	Server.Selfie_FavourByAuthentication = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Selfie/FavourByAuthentication";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Selfiecomment1_Insert = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Selfiecomment1/Insert";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Selfiecomment2_Insert = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Selfiecomment2/Insert";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Selfiecomment1_GetCountByMapTables = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Selfiecomment1/GetCountByMapTables";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Selfiecomment1_FindByUnread = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Selfiecomment1/FindByUnread";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	Server.Selfiecomment1_FindByState = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Selfiecomment1/FindByState";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
  	  	
	Server.Selfie_FindByMapPage = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Selfie/FindByMapPage";
   		self.Get2(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
	Server.Selfiecomment1_FindByMapPage = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Selfiecomment1/FindByMapPage";
   		self.Get2(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
 	Server.Selfiecomment2_FindByMapPage = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Selfiecomment2/FindByMapPage";
   		self.Get2(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
	Server.Selfiecollect_Insert = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Selfiecollect/Insert";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
   	Server.Selfiecollect_FindByMapPage = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Selfiecollect/FindByMapPage";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
   	Server.Selfiecollect_FindAllByAuthentication = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Selfiecollect/FindAllByAuthentication";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
   	
//==================================容云即时通讯==============================
	//获取融云token
  	Server.Rong2_RongToken = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Rong2/RongToken";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
	//初始化融云
	Server.initRong2 = function(){
		var self = this;
		var rong = api.require('rongCloud2');
		rong.init(function(ret, err) {
		    if (ret.status == 'success'){
		    	self.connectRong2();
		    }else{
		    	console.log("融云初始化失败："+JSON.stringify(err))
		    }
		});
    }
	//连接融云
    Server.connectRong2 = function(){
    	var self = this;
    	api.getPrefs({
		    key: 'rongToken'
		}, function(ret, err) {
		    var rongToken = ret.value;
		    if(rongToken != ""){
//		    	//设置监听器
		    	self.rongListener();
		    	//连接融云服务器
		    	var rong = api.require('rongCloud2');
		    	rong.connect({token: rongToken},function(ret, err) {
				    if (ret.status == 'success'){
						console.log("连接融云服务器成功"+JSON.stringify(ret));
							
				    }else{
				    	if(err.code == 31004){//错误的令牌（Token），Token 解析失败，请重新向身份认证服务器获取 Token
				    		self.Rong2_RongToken({},function(data){
					    		if(data.code == 1){
					    			api.setPrefs({ key: 'rongToken', value: data.msg});
					    			self.connectRong2();
					    		}
					    	});
				    	}
				    	console.log("融云connect错误："+JSON.stringify(err));
				    }
				});
		    }else{//获取融云token
		    	self.Rong2_RongToken({},function(data){
		    		if(data.code == 1){
		    			api.setPrefs({ key: 'rongToken', value: data.msg});
		    			self.connectRong2();
		    		}
		    	});
		    }
		});
    }
    Server.rongListener = function(){
    	//连接状态监听
    	var rong = api.require('rongCloud2');
    	rong.setConnectionStatusListener(function(ret, err) {
//	    	CONNECTED // 连接成功
//			CONNECTING // 连接中
//			DISCONNECTED // 断开连接
//			KICKED // 用户账户在其他设备登录，本机会被踢掉线
//			NETWORK_UNAVAILABLE // 网络不可用
//			SERVER_INVALID // 服务器异常或无法连接
//			TOKEN_INCORRECT // Token 不正确
			console.log(JSON.stringify(ret));
			if(ret.result.connectionStatus == "KICKED"){//被踢下线
				api.setPrefs({key: 'accessToken',value: ""});
				api.setPrefs({key: 'refreshToken',value: ""});
				api.setPrefs({key: 'user',value: ""});
				//断开融云连接
				api.setPrefs({key: 'rongToken',value: ""});
				var rong = api.require('rongCloud2');
				rong.logout(function(ret, err) { }); // 断开，且不再接收 Push
				//刷新侧滑视图
				api.execScript({ name: 'slide', script: 'refreshView();' });
				api.setPrefs({key: 'frame_index',value: 0});
				api.alert({title: "您的账户在其他设备登录",msg: "您已被踢下线，如不是您本人操作，请及时修改密码以确保账户安全。"})
			}
			if(ret.result.connectionStatus == 'NETWORK_UNAVAILABLE'){
				api.toast({msg:"网络不可用，请检查您的网络！"});
			}
		});
		//设置接收消息的监听器
		rong.setOnReceiveMessageListener(function(ret, err) {
//		    api.toast({ msg: JSON.stringify(ret.result.message) });
//		    api.toast({ msg: ret.result.message.left });
			console.log("接受到一条消息:"+ JSON.stringify(ret.result));
			//一次处理消息
			if(ret.result.message.content.extra == "loginGame"){
				api.setPrefs({ key: 'localGameState', value: 'loginGame' });
				api.execScript({ name: 'game_info_win', frameName: 'game_info_frame', script: "setBtColor()" });
				api.execScript({ name: 'game_info_win', frameName: 'game_info_frame', script: "getNetData()" });
			}
			if(ret.result.message.content.extra == "inviteGame"){
				api.setPrefs({ key: 'localGameState', value: 'inviteGame' });
				api.execScript({ name: 'game_info_win', frameName: 'game_info_frame', script: "setBtColor()" });
			}
			if(ret.result.message.content.extra == "startGame"){
				api.setPrefs({ key: 'localGameState', value: 'startGame' });
				api.execScript({ name: 'game_info_win', frameName: 'game_info_frame', script: "setBtColor()" });
			}
			if(ret.result.message.content.extra == "overGame"){
				api.setPrefs({ key: 'localGameState', value: '' });
				api.execScript({ name: 'game_info_win', frameName: 'game_info_frame', script: "setBtColor()" });
				api.execScript({ name: 'game_info_win', frameName: 'game_info_frame', script: "getNetData()" });
			}
			
			api.execScript({
			    name: 'game_info_win',
			    frameName: 'game_info_frame',
			    script: "receiveChat(\'"+ JSON.stringify(ret.result) +"\')"
			});
		});
    }
	Server.Rong2_RongOnlineState = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Rong2/RongOnlineState";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
//====================================找撸友=========================================
	Server.Gamefriends_Insert = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Gamefriends/Insert";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
	Server.Gamefriends_FindByMapPage = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Gamefriends/FindByMapPage";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
	Server.Gamefriends_FindByMapPageIn = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Gamefriends/FindByMapPageIn";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
	Server.Gamefriends_UpdateByMap = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Gamefriends/UpdateByMap";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
	Server.Gamefriendscollect_Insert = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Gamefriendscollect/Insert";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
	Server.Gamefriendscollect_FindByMapPage = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Gamefriendscollect/FindByMapPage";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }

//===========================系统消息=================================
	Server.Reportcategory_FindByMapPage = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Reportcategory/FindByMapPage";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
	Server.Reportinformation_Insert = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Reportinformation/Insert";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
	Server.Reportinformation_FindByMapPage = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Reportinformation/FindByMapPage";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
	Server.Reportinformation_UpdateByMap = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Reportinformation/UpdateByMap";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }
	Server.Reportinformation_GetCountByMap = function(req_data,callback){
   		var self = this;
   		var url = self.ipAddress + "/Reportinformation/GetCountByMap";
   		self.Get(url,{values:req_data},function(ret){
   			callback(ret);
   		});
    }






    window.Server = Server;
})(window,jQuery,JSEncrypt);


